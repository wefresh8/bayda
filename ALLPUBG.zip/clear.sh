rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/app_*
touch /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/app_*
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/app_*
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/cache
touch /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/cache
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/cache
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/code_cache
touch /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/code_cache
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins//com.pubg.krmobile/code_cache
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/databases
touch /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/databases
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/databases
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/files
touch /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/files
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/files
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.pubg.krmobile/no_backup

rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/cache
touch /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/cache
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/cache
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/databases
touch /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/databases
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/databases
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/shared_prefs
touch /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/shared_prefs
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.simmu.mods/shared_prefs

rm -rf /data/user/0/com.excean.dualaid/cache
rm -rf /data/user/0/com.excean.dualaid/code_cache


rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/app_*
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/app_*
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/app_*
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/cache
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/cache
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/cache
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/code_cache
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/code_cache
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/code_cache
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/databases
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/databases
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/databases
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/files
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/files
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/files
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.pubg.krmobile/no_backup

rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/app_*
touch /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/app_*
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/app_*
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/cache
touch /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/cache
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/cache
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/code_cache
touch /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/code_cache
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/code_cache
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/databases
touch /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/databases
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/databases
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/files
touch /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/files
chmod -R 000 /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/files
rm -rf /data/user/0/com.excean.dualaid/gameplugins/com.tencent.ig/no_backup

rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_*
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_*
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_*
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/cache
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/cache
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/cache
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/code_cache
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/code_cache
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/code_cache
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/databases
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/databases
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/databases
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/files
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/files
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/files
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/no_backup
rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/shared_prefs
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/shared_prefs
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/shared_prefs

rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_webview_com.tencent.ig
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_webview_com.tencent.ig
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_webview_com.tencent.ig

rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_flutter
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_flutter
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_flutter

rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_crashSight
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_crashSight
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_crashSight

rm -rf /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_crashSight
touch /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_crashSight
chmod -R 000 /data/user/0/roc.com.pubg.imobile/data/user/0/com.tencent.ig/app_crashSight

rm -rf /data/user/0/com.pubg.krmobile/app_*
touch /data/user/0/com.pubg.krmobile/app_*
chmod -R 000 /data/user/0/com.pubg.krmobile/app_*
rm -rf /data/user/0/com.pubg.krmobile/cache
touch /data/user/0/com.pubg.krmobile/cache
chmod -R 000 /data/user/0/com.pubg.krmobile/cache
rm -rf /data/user/0/com.pubg.krmobile/code_cache
touch /data/user/0/com.pubg.krmobile/code_cache
chmod -R 000 /data/user/0/com.pubg.krmobile/code_cache
rm -rf /data/user/0/com.pubg.krmobile/databases
touch /data/user/0/com.pubg.krmobile/databases
chmod -R 000 /data/user/0/com.pubg.krmobile/databases
rm -rf /data/user/0/com.pubg.krmobile/files
touch /data/user/0/com.pubg.krmobile/files
chmod -R 000 /data/user/0/com.pubg.krmobile/files
rm -rf /data/user/0/com.pubg.krmobile/no_backup

rm -rf /data/user/0/com.tencent.ig/app_*
touch /data/user/0/com.tencent.ig/app_*
chmod -R 000 /data/user/0/com.tencent.ig/app_*
rm -rf /data/user/0/com.tencent.ig/cache
touch /data/user/0/com.tencent.ig/cache
chmod -R 000 /data/user/0/com.tencent.ig/cache
rm -rf /data/user/0/com.tencent.ig/code_cache
touch /data/user/0/com.tencent.ig/code_cache
chmod -R 000 /data/user/0/com.tencent.ig/code_cache
rm -rf /data/user/0/com.tencent.ig/databases
touch /data/user/0/com.tencent.ig/databases
chmod -R 000 /data/user/0/com.tencent.ig/databases
rm -rf /data/user/0/com.tencent.ig/files
touch /data/user/0/com.tencent.ig/files
chmod -R 000 /data/user/0/com.tencent.ig/files
rm -rf /data/user/0/com.tencent.ig/no_backup

rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache
touch /storage/emulated/0/Android/data/com.pubg.krmobile/cache
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/hawk_data
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/hawk_data
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/hawk_data
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/TGPA
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/TGPA
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramIncompatible
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramIncompatible
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramIncompatible
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/log
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/log
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/log
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/iMSDK
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/iMSDK
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/iMSDK
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/centauri
touch /storage/emulated/0/Android/data/com.pubg.krmobile/files/centauri
chmod -R 000 /storage/emulated/0/Android/data/com.pubg.krmobile/files/centauri
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*

rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18142.pak
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18169.pak


rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
touch /storage/emulated/0/Android/data/com.tencent.ig/cache
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/hawk_data
touch /storage/emulated/0/Android/data/com.tencent.ig/files/hawk_data
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/hawk_data
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
touch /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
touch /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA
touch /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramIncompatible
touch /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramIncompatible
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramIncompatible
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
touch /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/log
touch /storage/emulated/0/Android/data/com.tencent.ig/files/log
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/log
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/iMSDK
touch /storage/emulated/0/Android/data/com.tencent.ig/files/iMSDK
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/iMSDK
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/centauri
touch /storage/emulated/0/Android/data/com.tencent.ig/files/centauri
chmod -R 000 /storage/emulated/0/Android/data/com.tencent.ig/files/centauri
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*

rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*

rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18142.pak
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18169.pak




rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/cache
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/cache
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/hawk_data
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/hawk_data
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/hawk_data
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/cacheFile.txt
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/cacheFile.txt
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/login-identifier.txt
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/login-identifier.txt
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/TGPA
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/TGPA
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/TGPA
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/ProgramIncompatible
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/ProgramIncompatible
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/ProgramIncompatible
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/log
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/log
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/log
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/iMSDK
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/iMSDK
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/iMSDK
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/centauri
touch /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/centauri
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/centauri
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*
rm -rf /storage/emulated/0/SdCard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*

rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/cache
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/cache
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/hawk_data
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/hawk_data
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/hawk_data
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/cacheFile.txt
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/cacheFile.txt
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/login-identifier.txt
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/login-identifier.txt
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/TGPA
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/TGPA
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/TGPA
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/ProgramIncompatible
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/ProgramIncompatible
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/ProgramIncompatible
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/ProgramBinaryCache
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/ProgramBinaryCache
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/ProgramBinaryCache
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/log
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/log
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/log
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/iMSDK
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/iMSDK
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/iMSDK
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/centauri
touch /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/centauri
chmod -R 000 /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/centauri
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*
rm -rf /storage/emulated/0/SdCard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*


rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/cache
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/cache
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/hawk_data
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/hawk_data
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/hawk_data
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/cacheFile.txt
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/cacheFile.txt
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/login-identifier.txt
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/login-identifier.txt
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/TGPA
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/TGPA
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/ProgramIncompatible
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/ProgramIncompatible
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/ProgramIncompatible
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/ProgramBinaryCache
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/ProgramBinaryCache
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/log
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/log
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/log
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/iMSDK
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/iMSDK
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/iMSDK
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/centauri
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/centauri
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/centauri
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18142.pak
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18169.pak

rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/cache
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/cache
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/hawk_data
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/hawk_data
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/hawk_data
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/cacheFile.txt
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/cacheFile.txt
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/login-identifier.txt
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/login-identifier.txt
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/TGPA
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/TGPA
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/TGPA
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/ProgramIncompatible
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/ProgramIncompatible
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/ProgramIncompatible
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/ProgramBinaryCache
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/ProgramBinaryCache
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/log
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/log
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/log
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/iMSDK
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/iMSDK
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/iMSDK
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/centauri
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/centauri
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/centauri
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_59_2.9.0.18160_20231124194752_417469869_cures.ifs.cures.curesbk
touch /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_59_2.9.0.18160_20231124194752_417469869_cures.ifs.cures.curesbk
chmod -R 000 /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_59_2.9.0.18160_20231124194752_417469869_cures.ifs.cures.curesbk
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch*

rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18142.pak
rm -rf /storage/emulated/0/Android/data/com.excean.dualaid/gameplugins/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/res_pufferpatch.2.9.0.18169.pak